package fbAutomation;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

public class FBLogin {

	static By id_email = By.id("email");
	static By id_password = By.id("pass");

	public static String Email(String email) {

		DriverSetup.driver.findElement(id_email).sendKeys(email);

		return email;
	}

	public static String Password(String pass) {

		DriverSetup.driver.findElement(id_password).sendKeys(pass + Keys.ENTER);

		return pass;
	}

}
