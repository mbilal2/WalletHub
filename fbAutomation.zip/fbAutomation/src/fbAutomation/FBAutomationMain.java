package fbAutomation;

import java.util.Scanner;

public class FBAutomationMain {

	public static void main(String[] args) throws InterruptedException {

		DriverSetup.browserSetup();

		Scanner myScanner = new Scanner(System.in);
		System.out.println("Enter username");

		String userName = myScanner.nextLine();

		System.out.println("Enter Password");
		String password = myScanner.nextLine();

		myScanner.close();

		FBLogin.Email(userName);
		FBLogin.Password(password);

		CreatePost.Click_FeedText();
		CreatePost.PostFeed();

		DriverSetup.driver.quit();

	}

}
