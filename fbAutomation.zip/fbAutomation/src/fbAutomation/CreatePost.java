package fbAutomation;

import org.openqa.selenium.By;

public class CreatePost {

	static By xpath_feedText = By.xpath(
			"/html/body/div[1]/div/div[1]/div/div[3]/div/div/div[1]/div[1]/div/div[2]/div/div/div[3]/div/div[2]/div/div/div/div[1]/div/div[1]");

	static By xpath_btnPost = By.xpath(
			"/html/body/div[1]/div/div[1]/div/div[4]/div/div/div[1]/div/div[2]/div/div/div/form/div/div[1]/div/div/div/div[3]/div[2]/div/div/div[1]");

	public static void Click_FeedText() throws InterruptedException {

		Thread.sleep(10000);
		DriverSetup.driver.findElement(xpath_feedText).click();

	}

	public static void PostFeed() throws InterruptedException {

		Thread.sleep(4000);
		DriverSetup.driver.switchTo().activeElement().sendKeys("Hello World");

		Thread.sleep(3000);
		DriverSetup.driver.findElement(xpath_btnPost).click();

	}
}
