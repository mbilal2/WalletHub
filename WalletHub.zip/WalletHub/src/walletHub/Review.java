package walletHub;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class Review {

	static By xpath_Reviewstar = By.cssSelector(".ng-enter-element .rvs-star-svg:nth-of-type(4)");

	static By xpath_writeReview = By.xpath(
			"/html/body/web-app/div/div[1]/main/div[2]/div/div[3]/section/modal-dialog/div/div/write-review/div/div[1]/textarea");

	static By xpath_selectDropdown = By.xpath(
			"/html/body/web-app/div/div[1]/main/div[2]/div/div[3]/section/modal-dialog/div/div/write-review/div/ng-dropdown/div/span");

	static By xpath_dropdown_value = By
			.xpath("//*[@id=\"reviews-section\"]/modal-dialog/div/div/write-review/div/ng-dropdown/div/ul/li[2]");

	static By xpath_btnSubmit = By.xpath(
			"/html/body/web-app/div/div[1]/main/div[2]/div/div[3]/section/modal-dialog/div/div/write-review/sub-navigation/div/div[2]");

	public static void Rating() throws InterruptedException {

		Actions action = new Actions(DriverClass.Chdriver);

		WebElement settings = DriverClass.Chdriver.findElement(xpath_Reviewstar);
		action.moveToElement(settings);
		action.pause(5000).build().perform();
		settings.click();

	}

	public static String write_Review(String review) throws InterruptedException {

		DriverClass.Chdriver.findElement(xpath_writeReview).sendKeys(review);
		Thread.sleep(3000);
		return review;

	}

	public static void Select_dropDownValue() throws InterruptedException {

		DriverClass.Chdriver.findElement(xpath_selectDropdown).click();
		DriverClass.Chdriver.findElement(xpath_dropdown_value).click();

		Thread.sleep(3000);

	}

	public static void click_Submit() throws InterruptedException {

		DriverClass.Chdriver.findElement(xpath_btnSubmit).click();
		Thread.sleep(5000);

	}

	public static String verify_review() {

		DriverClass.Chdriver.navigate().to("https://wallethub.com/profile/test-insurance-company-13732055i");

		String text = DriverClass.Chdriver.findElement(By.xpath(
				"/html/body/web-app/div/div[1]/main/div[2]/div/div[3]/section/section/article[1]/div[2]/div[2]/span[1]"))
				.getText();

		return text;

	}

	public static void Review_successfull() throws InterruptedException {

		Thread.sleep(10000);

		String URL = DriverClass.Chdriver.getCurrentUrl();
		System.out.println("current URL " + URL);

		if (URL.contains("confirm-review")) {

			System.out.println("Congrats: ");

		} else {

			System.out.println("Sorry !!! : ");

		}
	}

}
