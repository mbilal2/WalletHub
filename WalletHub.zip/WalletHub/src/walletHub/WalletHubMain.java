package walletHub;

public class WalletHubMain {

	static String email = "atest@gmail.com";
	static String password = "Password1@";
	static String review = "Its random review for testing. Its random review for testing. Its random review for testing. Its random review for testing. Its random review for testing. It is random review for testing. Comment over";

	public static void main(String[] args) throws InterruptedException {

		DriverClass.BrowserSetup();

		SignUp.Enter_Email(email);
		SignUp.Enter_Password(password);
		SignUp.Enter_ConfirmPassword(password);
		SignUp.click_checkbox();
		SignUp.click_Join();

		if (SignUp.isLoginPage) {

			SignUp.Enter_LoginPass(password);
			SignUp.click_login();
			Thread.sleep(8000);

			DriverClass.Chdriver.navigate().to("http://wallethub.com/profile/test_insurance_company/");

		} else if (SignUp.isEmailError) {

			System.out.println("Please Enter Valid Email: ");
			DriverClass.Chdriver.quit();

		} else {

			DriverClass.Chdriver.navigate().to("http://wallethub.com/profile/test_insurance_company/");

		}

		Review.Rating();
		Review.write_Review(review);
		Review.Select_dropDownValue();
		Review.click_Submit();
		Review.Review_successfull();

		String Text = Review.verify_review();

		if (Text.equals("Your Review")) {

			System.out.println("Text is == " + Text);
			DriverClass.Chdriver.quit();

		} else {

			System.out.println("This Review is posted by, " + Text);

		}

	}

}
