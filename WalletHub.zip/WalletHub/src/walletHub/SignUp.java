package walletHub;
import org.openqa.selenium.By;

public class SignUp {

	static boolean isLoginPage, isEmailError;

	static By name_Email = By.name("em");
	static By name_Password = By.name("pw1");
	static By name_confirmPass = By.name("pw2");
	static By class_Checkbox_Getfreescore = By.xpath("/html/body/main/div/form/div/div[4]/label/span");
	static By class_btnJoin = By.className("btns");
	static By name_LoginPassword = By.name("pw");
	static By xpath_btnLogin = By.xpath("/html/body/main/div/form/div[4]/button[2]/span");
	static By xpath_ExistAccountMessage = By.xpath("/html/body/main/div/form/h1");
	static By xpath_ErrorEmail = By.xpath("/html/body/main/div/form/div/div[1]/div/span[2]");

	public static String Enter_Email(String email) {

		DriverClass.Chdriver.findElement(name_Email).clear();
		DriverClass.Chdriver.findElement(name_Email).sendKeys(email);

		return email;

	}

	public static String Enter_Password(String password) {

		DriverClass.Chdriver.findElement(name_Password).sendKeys(password);

		return password;

	}

	public static String Enter_ConfirmPassword(String pass) {

		DriverClass.Chdriver.findElement(name_confirmPass).sendKeys(pass);

		return pass;

	}

	public static void click_checkbox() {

		DriverClass.Chdriver.findElement(class_Checkbox_Getfreescore).click();

	}

	public static void click_Join() throws InterruptedException {

		DriverClass.Chdriver.findElement(class_btnJoin).click();
		Thread.sleep(6000);

		isLoginPage = DriverClass.Chdriver.findElements(xpath_ExistAccountMessage).size() > 0;
		isEmailError = DriverClass.Chdriver.findElements(xpath_ErrorEmail).size() > 0;

	}

	public static String Enter_LoginPass(String pass) {

		DriverClass.Chdriver.findElement(name_LoginPassword).sendKeys(pass);

		return pass;

	}

	public static void click_login() {

		DriverClass.Chdriver.findElement(xpath_btnLogin).click();
	}
}
