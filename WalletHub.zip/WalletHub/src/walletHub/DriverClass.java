package walletHub;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class DriverClass {

	static WebDriver Chdriver;

	public static void BrowserSetup() throws InterruptedException {

		System.setProperty("webdriver.chrome.driver", "Resources\\chromedriver.exe");
		Chdriver = new ChromeDriver();
		Chdriver.manage().window().maximize();
		Chdriver.navigate().to("https://wallethub.com/join/light");

		Thread.sleep(8000);

	}
}
